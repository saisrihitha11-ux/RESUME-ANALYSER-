# ResumeLens – ATS Resume Analyser

Upload a resume (PDF, DOCX, TXT) and get an ATS-friendly %, resume strength score, feedback and tips.
Optionally paste a job description to see a keyword match. Everything runs in the browser — nothing is uploaded.

## Run in VS Code
1. Open this folder in VS Code.
2. Install the **Live Server** extension (Ritwick Dey).
3. Right-click `index.html` → **Open with Live Server**.

Alternative: run `npm start` in the VS Code terminal and open the URL shown.
An internet connection is needed for the PDF/DOCX libraries and fonts (loaded from CDN).

## Files
- `index.html` – layout · `style.css` – design
- `analyzer.js` – scoring rules (edit weights/keywords here)
- `app.js` – file reading and results display
