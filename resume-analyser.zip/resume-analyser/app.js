pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
const $=id=>document.getElementById(id);
const drop=$('drop'),fileIn=$('file');
drop.onclick=()=>fileIn.click();
drop.onkeydown=e=>{if(e.key==='Enter'||e.key===' ')fileIn.click()};
['dragover','dragenter'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add('over')}));
['dragleave','drop'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove('over')}));
drop.addEventListener('drop',e=>handle(e.dataTransfer.files[0]));
fileIn.onchange=()=>handle(fileIn.files[0]);
$('again').onclick=()=>{$('results').hidden=true;$('upload').hidden=false;fileIn.value='';scrollTo(0,0)};

async function extract(file){
  const ext=file.name.split('.').pop().toLowerCase();
  if(ext==='txt')return file.text();
  const buf=await file.arrayBuffer();
  if(ext==='docx')return (await mammoth.extractRawText({arrayBuffer:buf})).value;
  if(ext==='pdf'){
    const pdf=await pdfjsLib.getDocument({data:buf}).promise;let out='';
    for(let i=1;i<=pdf.numPages;i++){
      const c=await (await pdf.getPage(i)).getTextContent();
      let y=null;c.items.forEach(it=>{const ny=it.transform[5];out+=(y!==null&&Math.abs(ny-y)>2?'\n':' ')+it.str;y=ny});
      out+='\n';
    }
    return out;
  }
  throw new Error('Unsupported file type. Please upload a PDF, DOCX or TXT file.');
}

async function handle(file){
  if(!file)return;$('error').textContent='';$('loading').hidden=false;
  try{
    const text=await extract(file);
    if(text.trim().split(/\s+/).length<40)throw new Error('Could not read enough text. If this is a scanned image PDF, ATS systems cannot read it either — export a text-based PDF.');
    const r=analyze(text,$('jd').value);
    render(r,file.name);
  }catch(e){$('error').textContent=e.message||String(e)}
  $('loading').hidden=true;
}

const col=p=>p>=75?'#2de2b0':p>=50?'#ffc857':'#ff6b81';
const verdict=p=>p>=80?'Excellent — very likely to parse cleanly.':p>=65?'Good, with a few fixes to make.':p>=45?'Fair — several issues may hurt parsing.':'Needs work — fix the basics first.';
function ring(id,p,txt){const el=$(id);el.style.setProperty('--c',col(p));el.firstChild.textContent=txt;
  el.style.setProperty('--p',0);let n=0;const t=setInterval(()=>{n+=2;if(n>=p){n=p;clearInterval(t)}el.style.setProperty('--p',n)},12)}

function render(r,name){
  $('upload').hidden=true;$('results').hidden=false;$('fname').textContent=name;
  ring('ringAts',r.ats,r.ats+'%');$('atsText').textContent=verdict(r.ats);
  ring('ringAll',r.overall,r.overall);$('allText').textContent=`${r.words} words · ${r.overall>=75?'strong':'room to grow'}`;
  $('kwCard').hidden=!r.kw;$('kwBox').hidden=!r.kw;
  if(r.kw){ring('ringKw',r.kw.pct,r.kw.pct+'%');$('kwText').textContent=`${r.kw.found.length} of ${r.kw.total} keywords found`;
    $('kwFound').innerHTML=r.kw.found.map(k=>`<span>${k}</span>`).join('')||'None';
    $('kwMiss').innerHTML=r.kw.missing.map(k=>`<span>${k}</span>`).join('')||'<span style="background:none">Nothing missing 🎉</span>'}
  $('breakdown').innerHTML=r.cats.map(c=>`<div class="row"><div><span>${c.name}</span><b>${c.pct}%</b></div><div class="track"><div class="fill" style="background:${col(c.pct)}" data-w="${c.pct}"></div></div></div>`).join('');
  setTimeout(()=>document.querySelectorAll('.fill').forEach(f=>f.style.width=f.dataset.w+'%'),50);
  $('good').innerHTML=r.good.map(g=>`<li>${g}</li>`).join('')||'<li>Nothing yet — follow the tips below.</li>';
  $('bad').innerHTML=r.bad.map(g=>`<li>${g}</li>`).join('')||'<li>No major issues found.</li>';
  $('tips').innerHTML=r.tips.map(t=>`<div class="tip"><b>${t.title}</b>${t.body}<br><small>${t.gain}</small></div>`).join('');
  scrollTo(0,0);
}
