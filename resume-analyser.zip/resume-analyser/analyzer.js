const VERBS='achieved managed led developed designed built created implemented improved increased reduced launched delivered optimized analyzed automated coordinated drove established executed generated initiated mentored negotiated organized planned produced resolved streamlined supervised trained transformed engineered deployed migrated architected collaborated spearheaded owned scaled boosted cut saved won secured maintained tested integrated researched presented'.split(' ');
const WEAK=['responsible for','duties included','worked on','helped with','tasked with','hard working','hardworking','team player','results-oriented','results oriented','go-getter','detail oriented','detail-oriented','think outside the box','references available','objective'];
const SKILLS='javascript typescript python java c++ c# react angular vue node sql mysql postgresql mongodb aws azure gcp docker kubernetes git linux html css api rest agile scrum jira excel tableau power bi machine learning data analysis communication leadership project management problem solving teamwork seo marketing sales budgeting forecasting customer service ci/cd testing figma'.split(' ');
const STOP=new Set('the and for with you your are our will this that from have has was were their they them but not all can any may who about into more than also other such its it\'s per etc able work role team job years year experience skills ability including responsibilities requirements strong good new use using used within across join looking required preferred plus must should would could what when where which while very'.split(' '));

function analyze(text,jd){
  const t=text.toLowerCase(),words=text.split(/\s+/).filter(Boolean),wc=words.length;
  const checks=[],good=[],bad=[],tips=[];
  const add=(cat,name,score,w,okMsg,badMsg,tip)=>{
    score=Math.max(0,Math.min(1,score));checks.push({cat,name,score,w});
    if(score>=.75)good.push(okMsg);else{bad.push(badMsg);if(tip)tips.push({title:tip[0],body:tip[1],gain:`Potential gain: +${Math.round((1-score)*w)} points`,w:(1-score)*w})}
  };
  const email=/[\w.+-]+@[\w-]+\.[\w.]+/.test(text),phone=/(\+?\d[\d\s().-]{8,}\d)/.test(text);
  const link=/linkedin\.com|github\.com|portfolio|behance|gitlab/.test(t);
  add('Format & ATS','Contact info',(email?.5:0)+(phone?.5:0),10,'Email and phone number found.','Missing '+(email?'phone number':phone?'email address':'email and phone')+'.',['Add complete contact details','Put your email and phone in plain text at the top of the page — not inside a header/footer, image or text box.']);
  add('Format & ATS','Profile links',link?1:0,4,'LinkedIn / portfolio link included.','No LinkedIn, GitHub or portfolio link found.',['Link your online profile','Add a clean LinkedIn URL (and GitHub or portfolio if relevant). Recruiters check them.']);
  const sec={experience:/(work |professional )?experience|employment|work history/,education:/education|academic|qualification/,skills:/skills|technologies|competencies|tools/,summary:/summary|profile|about me|objective/,projects:/projects|achievements|certifications|awards/};
  const have=Object.keys(sec).filter(k=>sec[k].test(t));
  [['experience',10],['education',8],['skills',10],['summary',4],['projects',4]].forEach(([k,w])=>
    add('Format & ATS',k[0].toUpperCase()+k.slice(1)+' section',sec[k].test(t)?1:0,w,`"${k}" section detected.`,`No clear "${k}" section heading.`,[`Add a standard "${k[0].toUpperCase()+k.slice(1)}" heading`,'ATS software looks for conventional headings. Avoid creative names like "My Journey".']));
  add('Format & ATS','Length',wc>=350&&wc<=900?1:wc>=250&&wc<=1100?.6:.25,8,`Good length (${wc} words).`,`Length is ${wc<350?'too short':'too long'} (${wc} words).`,['Aim for 400–800 words','One page for under 10 years of experience, two pages maximum. Cut older or irrelevant roles.']);
  const dates=(text.match(/\b(19|20)\d{2}\b/g)||[]).length;
  add('Format & ATS','Dates',dates>=4?1:dates/4,6,'Employment dates are present.','Few dates found.',['Add dates to every role and degree','Use a consistent format such as "Jan 2022 – Mar 2024".']);
  const bullets=(text.match(/^\s*[•▪●◦·\-–*]/gm)||[]).length;
  add('Format & ATS','Bullet points',bullets>=8?1:bullets/8,6,'Achievements are written as bullets.','Few bullet points detected.',['Use bullet points for achievements','3–5 short bullets per role are easier for both ATS and recruiters to scan.']);
  const odd=(text.match(/[^\x00-\x7F•–—’‘“”…·●▪◦]/g)||[]).length;
  add('Format & ATS','Clean text',odd<15?1:odd<50?.6:.2,5,'Text is clean and machine-readable.','Unusual symbols found (icons, tables or columns).',['Avoid icons, tables and graphics','Use one column and plain fonts. Replace icons with words like "Email:".']);

  const found=VERBS.filter(v=>new RegExp('\\b'+v+'\\b').test(t));
  add('Content','Action verbs',found.length/12,10,`Strong action verbs used (${found.length}).`,`Only ${found.length} strong action verbs found.`,['Start bullets with strong verbs','Use "Led", "Built", "Reduced", "Launched" instead of "Responsible for".']);
  const nums=(text.match(/\d+(\.\d+)?\s?(%|k\b|m\b|x\b)|[$£€₹]\s?\d|\b\d{2,}\+?\b/g)||[]).length;
  add('Content','Measurable results',nums/8,14,'Results are backed by numbers.','Few measurable achievements.',['Quantify your impact','Add numbers: "Cut load time by 40%", "Managed a team of 6", "Saved $12k a year".']);
  const weak=WEAK.filter(p=>t.includes(p));
  add('Content','Clichés & weak phrases',1-weak.length*.25,6,'No weak phrases or clichés.',`Weak phrases found: ${weak.slice(0,4).join(', ')}.`,['Replace weak phrases',`Remove or rewrite: ${weak.slice(0,5).join(', ')}. Show the result instead of describing the duty.`]);
  const fp=(t.match(/\b(i|my|me)\b/g)||[]).length;
  add('Content','Professional tone',fp<=3?1:fp<=8?.6:.2,4,'Tone is professional.',`First-person pronouns used ${fp} times.`,['Drop "I" and "my"','Write in implied first person: "Built a dashboard…" rather than "I built my dashboard…".']);

  let kw=null;
  if(jd.trim().length>40){
    const freq={};(jd.toLowerCase().match(/[a-z][a-z+#./-]{2,}/g)||[]).forEach(w=>{if(!STOP.has(w))freq[w]=(freq[w]||0)+1});
    const top=Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,20).map(e=>e[0]);
    const f=top.filter(k=>t.includes(k)),m=top.filter(k=>!t.includes(k));
    kw={found:f,missing:m,total:top.length,pct:Math.round(f.length/Math.max(1,top.length)*100)};
    add('Keywords','Job description match',kw.pct/100,22,`${kw.pct}% of job keywords appear in your resume.`,`Only ${kw.pct}% of job keywords match.`,['Mirror the job description',`Naturally work in missing keywords such as: ${m.slice(0,6).join(', ')}.`]);
  }else{
    const s=SKILLS.filter(k=>t.includes(k));
    add('Keywords','Skills keywords',s.length/10,12,`Good range of skill keywords (${s.length}).`,`Only ${s.length} common skill keywords found.`,['Add a dedicated skills section','List role-specific tools and technologies. Paste a job description above to see exactly what to add.']);
  }
  const pct=cs=>Math.round(cs.reduce((a,c)=>a+c.score*c.w,0)/cs.reduce((a,c)=>a+c.w,0)*100);
  const names=[...new Set(checks.map(c=>c.cat))];
  const cats=names.map(n=>({name:n,pct:pct(checks.filter(c=>c.cat===n))}));
  tips.sort((a,b)=>b.w-a.w);
  return{words:wc,ats:pct(checks.filter(c=>c.cat==='Format & ATS')),overall:pct(checks),cats,good,bad,tips:tips.slice(0,8),kw};
}
